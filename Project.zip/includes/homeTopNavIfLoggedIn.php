<div id="topNav">
		<a href="index.php"><img class="navLogo" src="skins/logo.png"></a>
		<div class="cont_navTab">
			<a class="navTab" href="doclist.php">Doctor's List</a>
			<a class="navTab login_btn" href="login.php">Profile</a>
		</div>
	</div>