<div  class="leftNav">
		<a href="index.php"><img class="navLogo" src="skins/logo.png"></a>

		<div class="cont_tab">
			<a class="tab" href="support_pq.php">Pending Queries</a>
			<a class="tab" href="support_aq.php">Answered Queries</a>
			<a class="tab" href="support_appointment.php">Appointment Management</a>
			<a class="tab" href="support_profile.php">My Profile</a>
			

			<form method="POST"><button class="tab logout" type="submit" name="logOut">Logout</button></form>
		</div>
	</div>
