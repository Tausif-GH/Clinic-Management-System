<div  class="leftNav">
		<a href="index.php"><img class="navLogo" src="skins/logo.png"></a>

		<div class="cont_tab">
			<a class="tab" href="admin_admin.php">Admins</a>
			<a class="tab" href="admin_doc.php">Doctors</a>
			<a class="tab" href="admin_pat.php">Patients</a>
			<a class="tab" href="admin_support.php">Support</a>
			<a class="tab" href="admin_appt.php">Appointment Management</a>
			<a class="tab" href="admin_profile.php">My Profile</a>

			<form method="POST"><button class="tab logout" type="submit" name="logOut">Logout</button></form>
		</div>
	</div>
